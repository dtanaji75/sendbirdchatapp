export let config={
    appId:"BD4FC23B-DA19-47EC-9FC3-D9E5AEF926F6",
    date_format:'d/m/Y H:M:S',
    log_date_format:'d-m-Y',
    db_date_format:'Y-m-d H:M:S',
    log:true,
    log_folder:"../logs/",
    encryption_key:"edb586b0cf329ed30ace437a1d47e881",
    algorithm:"aes-256-cbc",
    database_url:"mongodb+srv://chatapp:K9ybwbseXlYdJek1@cluster0.vkoqy.mongodb.net/chatapp?retryWrites=true&w=majority",
}